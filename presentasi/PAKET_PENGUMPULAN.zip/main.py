#!/usr/bin/env python3
"""Online Book Catalog Organizer & Scraper."""

import argparse
import csv
import html
import re
import sys
import zipfile
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from urllib.parse import urljoin, urlsplit

import requests
from bs4 import BeautifulSoup


PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = PROJECT_DIR / "data"
OUTPUT_DIR = PROJECT_DIR / "output"
BACKUP_DIR = PROJECT_DIR / "backup"
PRICE_PATTERN = re.compile(r"(\d+(?:\.\d{1,2})?)")
CSV_FIELDS = ["title", "price_raw", "price_clean", "category", "url", "image_url"]
GBP_TO_IDR = Decimal("24227")
EXCHANGE_RATE_DATE = "6 November 2026"


def positive_integer(value):
    """Parse a positive integer for the --limit argument."""
    try:
        parsed = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("limit harus berupa bilangan bulat") from exc
    if parsed <= 0:
        raise argparse.ArgumentTypeError("limit harus lebih besar dari 0")
    return parsed


def valid_url(value):
    """Accept only absolute HTTP(S) URLs."""
    try:
        parsed = urlsplit(value)
        hostname = parsed.hostname
        parsed.port
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"URL tidak valid: {exc}") from exc
    if parsed.scheme not in {"http", "https"} or not hostname:
        raise argparse.ArgumentTypeError("URL harus berupa alamat HTTP atau HTTPS yang valid")
    return value


def setup_directories():
    """Create project data, output, and backup directories."""
    for directory in (DATA_DIR, OUTPUT_DIR, BACKUP_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def fetch_page(url):
    """Fetch and decode a page, honoring the encoding detected from its content."""
    response = requests.get(url, timeout=15)
    response.raise_for_status()
    response.encoding = response.apparent_encoding
    return BeautifulSoup(response.text, "html.parser")


def scrape_books(base_url, limit):
    """Collect up to limit books, following pagination links when available."""
    print(f"[*] Memulai web scraping dari: {base_url} (Target: {limit} data)...")
    books = []
    current_url = base_url
    visited_urls = set()

    while len(books) < limit and current_url and current_url not in visited_urls:
        visited_urls.add(current_url)
        soup = fetch_page(current_url)

        for item in soup.select("article.product_pod"):
            if len(books) >= limit:
                break

            title_link = item.select_one("h3 a[title][href]")
            price_element = item.select_one("p.price_color")
            if title_link is None or price_element is None:
                print("[!] Melewati entri buku dengan data judul/harga yang tidak lengkap.", file=sys.stderr)
                continue

            title = title_link.get("title", "").strip()
            raw_price = price_element.get_text(strip=True)
            image_element = item.select_one("img[src], img[data-src]")
            if not title or PRICE_PATTERN.search(raw_price) is None:
                print("[!] Melewati entri buku dengan judul atau harga yang tidak valid.", file=sys.stderr)
                continue

            image_path = (
                image_element.get("src") or image_element.get("data-src")
                if image_element is not None
                else ""
            )
            books.append(
                {
                    "title": title,
                    "price": raw_price,
                    "url": urljoin(current_url, title_link["href"]),
                    "image_url": urljoin(current_url, image_path) if image_path else "",
                }
            )

        next_link = soup.select_one("li.next a[href]")
        current_url = urljoin(current_url, next_link["href"]) if next_link else None

    if not books:
        raise ValueError("Tidak ada data buku valid yang berhasil dikumpulkan.")
    if len(books) < limit:
        print(f"[!] Hanya {len(books)} dari {limit} data yang tersedia.")
    else:
        print(f"[+] Berhasil mengumpulkan {len(books)} record buku.")
    return books


def process_and_filter_data(books, keyword):
    """Normalize book data, apply an optional title filter, and write output files."""
    raw_data_path = DATA_DIR / "raw_data.txt"
    csv_output_path = OUTPUT_DIR / "hasil_scraping.csv"
    report_output_path = OUTPUT_DIR / "laporan.txt"
    keyword_regex = re.compile(re.escape(keyword), re.IGNORECASE) if keyword else None
    processed_data = []

    for book in books:
        match = PRICE_PATTERN.search(book["price"])
        if match is None:
            print(f"[!] Harga tidak valid; entri '{book['title']}' dilewati.", file=sys.stderr)
            continue

        price = Decimal(match.group(1))
        if keyword_regex and not keyword_regex.search(book["title"]):
            continue

        processed_data.append(
            {
                "title": book["title"],
                "price_raw": book["price"],
                "price_clean": price,
                "category": "Premium" if price > Decimal("30.00") else "Standard",
                "url": book["url"],
                "image_url": book.get("image_url", ""),
            }
        )

    with raw_data_path.open("w", encoding="utf-8", newline="\n") as raw_file:
        for book in books:
            raw_file.write(
                f"Title: {book['title']} | Price: {book['price']} | URL: {book['url']}\n"
            )

    with csv_output_path.open("w", encoding="utf-8-sig", newline="") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS, lineterminator="\n")
        writer.writeheader()
        for row in processed_data:
            csv_row = row.copy()
            csv_row["price_clean"] = f"{row['price_clean']:.2f}"
            writer.writerow(csv_row)

    total_items = len(processed_data)
    average_price = (
        sum((row["price_clean"] for row in processed_data), Decimal("0")) / total_items
        if total_items
        else Decimal("0")
    )
    report_lines = [
        "=== LAPORAN RINGKASAN AUTOMATION SYSTEMS ===",
        "Tema: Online Book Catalog Organizer",
        f"Keyword Filter: {keyword or 'Tidak ada'}",
        f"Total Record Diproses: {total_items}",
        f"Rata-rata Harga Buku: £{average_price:.2f}",
        "",
        "Rincian Buku:",
    ]
    report_lines.extend(
        f"{index}. {row['title']} - {row['price_raw']} ({row['category']})"
        for index, row in enumerate(processed_data, 1)
    )
    report_output_path.write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    write_html_catalog(processed_data, keyword, average_price)

    print(f"[+] Data mentah disimpan ke: {raw_data_path}")
    print(f"[+] Data terstruktur disimpan ke: {csv_output_path}")
    print(f"[+] Laporan ringkasan disimpan ke: {report_output_path}")
    if keyword and not processed_data:
        print(f"[!] Tidak ada judul yang cocok dengan keyword '{keyword}'.")
    return processed_data


def write_html_catalog(books, keyword, average_price):
    """Create a responsive, searchable HTML catalog from the processed books."""
    catalog_path = OUTPUT_DIR / "index.html"
    premium_count = sum(book["category"] == "Premium" for book in books)
    cards = []

    def format_idr(amount):
        rounded = int((amount * GBP_TO_IDR).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
        return f"Rp{rounded:,}".replace(",", ".")

    for index, book in enumerate(books):
        title = html.escape(book["title"])
        safe_url = html.escape(book["url"], quote=True)
        safe_image_url = html.escape(book.get("image_url", ""), quote=True)
        category = html.escape(book["category"])
        image_markup = (
            f'<img class="book-image" src="{safe_image_url}" alt="Sampul buku: {title}" loading="lazy" decoding="async">'
            if safe_image_url
            else ""
        )
        cards.append(
            f"""
            <article class="book-card" data-title="{html.escape(book['title'].casefold(), quote=True)}"
                     data-category="{category}" data-price="{book['price_clean']:.2f}">
              <div class="book-cover">
                {image_markup}
                <span class="cover-fallback">Sampul tidak tersedia</span>
                <span class="cover-number">{index + 1:02d}</span>
              </div>
              <div class="book-info">
                <span class="badge {'premium' if category == 'Premium' else 'standard'}">{category}</span>
                <h2>{title}</h2>
                <div class="book-footer">
                  <span class="price">{format_idr(book['price_clean'])}</span>
                  <a class="book-link" href="{safe_url}" target="_blank" rel="noopener noreferrer"
                     aria-label="Lihat detail {title}">Lihat buku <span aria-hidden="true">↗</span></a>
                </div>
              </div>
            </article>"""
        )

    page = """<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#101a2d">
  <title>Katalog Buku | Bookfolio</title>
  <style>
    :root {
      color-scheme: dark;
      --ink: #edf0f7;
      --muted: #9aa6ba;
      --line: #2a354a;
      --paper: #151f32;
      --accent: #e6bd77;
      --navy: #0b1120;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background:
        radial-gradient(ellipse at 82% 9%, #293351 0, transparent 34%),
        radial-gradient(ellipse at 8% 38%, #172b3b 0, transparent 32%),
        linear-gradient(145deg, #0b1120 0%, #111a2b 48%, #101728 100%);
      background-attachment: fixed;
      color: var(--ink);
      font: 15px/1.55 Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    }
    a { color: inherit; }
    .topbar { border-bottom: 1px solid #ffffff12; background: #0b1120cc; color: #f8f6f1; backdrop-filter: blur(16px); }
    .topbar-inner, main { width: min(1120px, calc(100% - 48px)); margin: 0 auto; }
    .topbar-inner { height: 74px; display: flex; align-items: center; justify-content: space-between; }
    .brand { display: flex; align-items: center; gap: 12px; font-size: 15px; font-weight: 750; letter-spacing: .03em; }
    .brand-icon { display: grid; place-items: center; width: 36px; height: 36px; border: 1px solid #d7a85a88; border-radius: 11px; color: var(--accent); font-family: Georgia, serif; font-size: 20px; }
    .source { color: #b7c0d0; font-size: 13px; }
    main { padding: 58px 0 72px; }
    .eyebrow { color: var(--accent); font-size: 11px; font-weight: 800; letter-spacing: .17em; text-transform: uppercase; }
    h1 { margin: 8px 0 9px; font-family: Georgia, "Times New Roman", serif; font-size: clamp(36px, 5vw, 52px); font-weight: 500; letter-spacing: -.04em; line-height: 1.12; }
    .intro { max-width: 580px; margin: 0; color: var(--muted); font-size: 16px; }
    .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin: 34px 0 43px; }
    .stat { min-height: 94px; padding: 17px 20px; border: 1px solid #ffffff12; border-radius: 13px; background: linear-gradient(145deg, #19243aeb, #131c2deb); box-shadow: 0 14px 36px #00000018; }
    .stat-label { display: block; color: var(--muted); font-size: 12px; }
    .stat-value { display: block; margin-top: 5px; font-family: Georgia, "Times New Roman", serif; font-size: 26px; }
    .section-heading { display: flex; align-items: end; justify-content: space-between; gap: 20px; margin-bottom: 17px; }
    h2.section-title { margin: 0; font-family: Georgia, "Times New Roman", serif; font-size: 26px; font-weight: 500; }
    .result-count { margin: 4px 0 0; color: var(--muted); font-size: 13px; }
    .controls { display: flex; gap: 10px; margin: 21px 0 22px; }
    .search-wrap { position: relative; flex: 1; }
    .search-icon { position: absolute; top: 50%; left: 14px; color: #aab4c5; transform: translateY(-50%); pointer-events: none; }
    input, select { height: 46px; border: 1px solid #ffffff1c; border-radius: 9px; outline: none; background: #151f32; color: var(--ink); font: inherit; }
    input { width: 100%; padding: 0 14px 0 40px; }
    select { min-width: 148px; padding: 0 34px 0 12px; }
    input::placeholder { color: #8995aa; }
    input:focus, select:focus { border-color: #c99e5d; box-shadow: 0 0 0 3px #d7a85a22; }
    .book-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 17px; }
    .book-card { overflow: hidden; border: 1px solid #ffffff14; border-radius: 13px; background: linear-gradient(155deg, #19243a, #131c2d); box-shadow: 0 10px 28px #0000001c; transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease; }
    .book-card:hover { transform: translateY(-4px); border-color: #e6bd7755; box-shadow: 0 18px 34px #00000035; }
    .book-cover { position: relative; display: grid; min-height: 226px; place-items: center; overflow: hidden; background: radial-gradient(ellipse at 50% 42%, #273650, #111a2b 74%); }
    .book-image { display: block; width: 100%; height: 226px; padding: 18px; object-fit: contain; filter: drop-shadow(0 12px 12px #00000065); transition: transform .25s ease; }
    .book-card:hover .book-image { transform: scale(1.045); }
    .cover-fallback { display: none; color: #9aa6ba; font-size: 12px; }
    .book-cover.image-unavailable .cover-fallback { display: block; }
    .cover-number { position: absolute; right: 13px; bottom: 10px; color: #ffffffa8; font-size: 11px; letter-spacing: .1em; }
    .book-info { padding: 16px 17px 15px; }
    .badge { display: inline-flex; align-items: center; min-height: 23px; padding: 2px 9px; border-radius: 99px; font-size: 10px; font-weight: 750; letter-spacing: .04em; }
    .badge.premium { background: #493921; color: #f1c77d; }
    .badge.standard { background: #233b38; color: #9ed1b4; }
    .book-info h2 { display: -webkit-box; min-height: 48px; margin: 10px 0 15px; overflow: hidden; color: #e5e9f1; font-size: 14px; font-weight: 650; line-height: 1.55; -webkit-box-orient: vertical; -webkit-line-clamp: 2; }
    .book-footer { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding-top: 12px; border-top: 1px solid #ffffff14; }
    .price { color: #f0cb87; font-family: Georgia, "Times New Roman", serif; font-size: 19px; }
    .book-link { color: #e6bd77; font-size: 12px; font-weight: 700; text-decoration: none; }
    .book-link:hover { color: #ffe0a6; }
    .empty { grid-column: 1 / -1; padding: 40px 20px; border: 1px dashed #46516a; border-radius: 12px; color: var(--muted); text-align: center; }
    footer { padding-top: 25px; color: #9aa6ba; font-size: 12px; text-align: center; }
    @media (max-width: 780px) { .book-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 540px) {
      .topbar-inner, main { width: min(100% - 32px, 1120px); }
      .topbar-inner { height: 64px; }
      .source { font-size: 11px; }
      main { padding-top: 38px; }
      .stats { gap: 8px; margin: 25px 0 34px; }
      .stat { min-height: 78px; padding: 12px; }
      .stat-value { font-size: 21px; }
      .controls { flex-wrap: wrap; }
      .search-wrap { flex-basis: 100%; }
      select { flex: 1; }
      .book-grid { gap: 10px; }
      .book-cover { min-height: 185px; }
      .book-image { height: 185px; padding: 14px; }
      .book-info { padding: 12px; }
      .book-info h2 { font-size: 13px; }
      .book-link { font-size: 11px; }
    }
    @media (prefers-reduced-motion: reduce) { *, *::before, *::after { scroll-behavior: auto !important; transition-duration: .01ms !important; } }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="topbar-inner">
      <div class="brand"><span class="brand-icon" aria-hidden="true">B</span><span>BOOKFOLIO</span></div>
      <span class="source">Katalog pilihan · Books to Scrape</span>
    </div>
  </header>
  <main>
    <section aria-labelledby="page-title">
      <span class="eyebrow">Koleksi buku</span>
      <h1 id="page-title">Temukan bacaan<br>berikutnya.</h1>
      <p class="intro">Jelajahi koleksi buku pilihan dalam satu katalog yang rapi. Cari judul favorit dan lihat detailnya langsung.</p>
    </section>
    <section class="stats" aria-label="Ringkasan katalog">
      <div class="stat"><span class="stat-label">Total koleksi</span><strong class="stat-value">__TOTAL__ buku</strong></div>
      <div class="stat"><span class="stat-label">Harga rata-rata</span><strong class="stat-value">__AVERAGE__</strong></div>
      <div class="stat"><span class="stat-label">Koleksi premium</span><strong class="stat-value">__PREMIUM__ buku</strong></div>
    </section>
    <p class="result-count">Konversi GBP → IDR: £1 = Rp24.227 · Kurs per __RATE_DATE__ (Frankfurter)</p>
    <section aria-labelledby="collection-title">
      <div class="section-heading">
        <div><h2 class="section-title" id="collection-title">Jelajahi koleksi</h2><p class="result-count" id="result-count">Menampilkan __TOTAL__ buku</p></div>
      </div>
      <div class="controls">
        <label class="search-wrap"><span class="search-icon" aria-hidden="true">⌕</span><input id="search" type="search" placeholder="Cari judul buku..." aria-label="Cari judul buku"></label>
        <select id="category" aria-label="Filter kategori"><option value="">Semua kategori</option><option value="Premium">Premium</option><option value="Standard">Standard</option></select>
        <select id="sort" aria-label="Urutkan buku"><option value="default">Urutan awal</option><option value="title">Judul A–Z</option><option value="price-low">Harga terendah</option><option value="price-high">Harga tertinggi</option></select>
      </div>
      <div class="book-grid" id="book-grid">__CARDS__</div>
    </section>
    <footer>Dikumpulkan otomatis · Automation Systems</footer>
  </main>
  <script>
    const grid = document.getElementById("book-grid");
    const cards = [...grid.querySelectorAll(".book-card")];
    const search = document.getElementById("search");
    const category = document.getElementById("category");
    const sort = document.getElementById("sort");
    const resultCount = document.getElementById("result-count");
    grid.querySelectorAll(".book-image").forEach(image => {
      image.addEventListener("error", () => {
        image.closest(".book-cover").classList.add("image-unavailable");
        image.remove();
      }, { once: true });
    });
    const updateCatalog = () => {
      const query = search.value.trim().toLocaleLowerCase("id");
      const visible = cards.filter(card =>
        card.dataset.title.includes(query) &&
        (!category.value || card.dataset.category === category.value)
      );
      visible.sort((a, b) => {
        if (sort.value === "title") return a.dataset.title.localeCompare(b.dataset.title, "id");
        if (sort.value === "price-low") return Number(a.dataset.price) - Number(b.dataset.price);
        if (sort.value === "price-high") return Number(b.dataset.price) - Number(a.dataset.price);
        return cards.indexOf(a) - cards.indexOf(b);
      });
      cards.forEach(card => { card.hidden = true; });
      visible.forEach(card => { card.hidden = false; grid.append(card); });
      grid.querySelector(".empty")?.remove();
      if (!visible.length) grid.insertAdjacentHTML("beforeend", '<p class="empty">Buku tidak ditemukan. Coba kata kunci lain.</p>');
      resultCount.textContent = `Menampilkan ${visible.length} dari ${cards.length} buku`;
    };
    search.addEventListener("input", updateCatalog);
    category.addEventListener("change", updateCatalog);
    sort.addEventListener("change", updateCatalog);
  </script>
</body>
</html>"""
    page = (
        page.replace("__TOTAL__", str(len(books)))
        .replace("__AVERAGE__", format_idr(average_price))
        .replace("__PREMIUM__", str(premium_count))
        .replace("__RATE_DATE__", EXCHANGE_RATE_DATE)
        .replace("__CARDS__", "\n".join(cards))
    )
    catalog_path.write_text(page, encoding="utf-8")
    print(f"[+] Katalog web disimpan ke: {catalog_path}")


def create_backup_zip():
    """Create a ZIP archive containing processed output and raw input data."""
    backup_path = BACKUP_DIR / "backup_data.zip"
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for file_path in sorted(OUTPUT_DIR.rglob("*")):
            if file_path.is_file():
                archive.write(file_path, file_path.relative_to(OUTPUT_DIR))
        raw_data_path = DATA_DIR / "raw_data.txt"
        if raw_data_path.is_file():
            archive.write(raw_data_path, raw_data_path.name)
    print(f"[+] Backup berhasil dibuat di: {backup_path}")


def build_parser():
    parser = argparse.ArgumentParser(
        description="Automation Systems - Book Catalog Scraper & Organizer"
    )
    parser.add_argument(
        "--url",
        type=valid_url,
        default="https://books.toscrape.com/",
        help="URL target web scraping (HTTP atau HTTPS)",
    )
    parser.add_argument("--keyword", default="", help="Kata kunci untuk menyaring judul buku")
    parser.add_argument(
        "--limit",
        type=positive_integer,
        default=30,
        help="Jumlah maksimum data yang diambil (default: 30)",
    )
    parser.add_argument(
        "--backup",
        action="store_true",
        help="Buat file ZIP backup hasil pemrosesan",
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        setup_directories()
        books = scrape_books(args.url, args.limit)
        process_and_filter_data(books, args.keyword.strip())
        if args.backup:
            create_backup_zip()
    except (requests.RequestException, OSError, ValueError, zipfile.BadZipFile) as exc:
        print(f"[!] Proses gagal: {exc}", file=sys.stderr)
        return 1

    print("\n=== PROSES AUTOMATION SELESAI ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
