#!/usr/bin/env python3
"""Generate the UTS report PDF from the project's latest scraped CSV."""

import csv
from decimal import Decimal
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "output" / "hasil_scraping.csv"
REPORT_PATH = Path(__file__).resolve().parent / "laporan_uts.pdf"
NAVY = colors.HexColor("#14213A")
GOLD = colors.HexColor("#C49345")
INK = colors.HexColor("#263247")
MUTED = colors.HexColor("#627087")
PALE = colors.HexColor("#F1F4F8")
LINE = colors.HexColor("#DCE2EA")


def page_chrome(canvas, document):
    canvas.saveState()
    width, height = A4
    canvas.setFillColor(NAVY)
    canvas.rect(0, height - 11 * mm, width, 11 * mm, fill=1, stroke=0)
    canvas.setFillColor(GOLD)
    canvas.rect(0, height - 11 * mm, 7 * mm, 11 * mm, fill=1, stroke=0)
    canvas.setFillColor(MUTED)
    canvas.setFont("Helvetica", 8)
    canvas.drawString(20 * mm, 12 * mm, "UTS AUTOMATION SYSTEMS  |  BOOK CATALOG ORGANIZER")
    canvas.drawRightString(width - 20 * mm, 12 * mm, f"{document.page}")
    canvas.restoreState()


def build_styles():
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="CoverEyebrow",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=9,
            leading=13,
            textColor=GOLD,
            alignment=TA_CENTER,
            spaceAfter=12,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CoverTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=27,
            leading=33,
            textColor=NAVY,
            alignment=TA_CENTER,
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CoverSubtitle",
            parent=styles["Normal"],
            fontSize=12,
            leading=18,
            textColor=MUTED,
            alignment=TA_CENTER,
            spaceAfter=20,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SectionHeading",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=15,
            leading=19,
            textColor=NAVY,
            spaceBefore=8,
            spaceAfter=8,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyCopy",
            parent=styles["BodyText"],
            fontSize=9,
            leading=14,
            textColor=INK,
            spaceAfter=7,
        )
    )
    styles.add(
        ParagraphStyle(
            name="SmallCopy",
            parent=styles["BodyText"],
            fontSize=8,
            leading=11,
            textColor=INK,
        )
    )
    styles.add(
        ParagraphStyle(
            name="TableHead",
            parent=styles["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=8,
            leading=10,
            textColor=colors.white,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CenterStat",
            parent=styles["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=15,
            leading=20,
            textColor=NAVY,
            alignment=TA_CENTER,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CenterLabel",
            parent=styles["SmallCopy"],
            fontSize=7,
            leading=9,
            textColor=MUTED,
            alignment=TA_CENTER,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Callout",
            parent=styles["BodyText"],
            fontSize=8,
            leading=12,
            textColor=NAVY,
            backColor=PALE,
            borderColor=LINE,
            borderWidth=0.6,
            borderPadding=8,
            spaceBefore=5,
            spaceAfter=8,
        )
    )
    return styles


def paragraph(text, style):
    return Paragraph(text, style)


def make_table(rows, widths, header=True):
    table = Table(rows, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.35, LINE),
    ]
    if header:
        commands.extend(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
            ]
        )
    else:
        commands.extend(
            [
                ("BACKGROUND", (0, 0), (-1, -1), PALE),
                ("BOX", (0, 0), (-1, -1), 0.6, LINE),
            ]
        )
    table.setStyle(TableStyle(commands))
    return table


def load_records():
    try:
        with CSV_PATH.open(encoding="utf-8-sig", newline="") as source:
            records = list(csv.DictReader(source))
    except OSError as exc:
        raise SystemExit(f"CSV hasil scraping tidak dapat dibaca: {exc}") from exc
    required = {"title", "price_clean", "category", "url"}
    if records and not required.issubset(records[0]):
        missing = ", ".join(sorted(required - records[0].keys()))
        raise SystemExit(f"Kolom wajib tidak ditemukan pada CSV: {missing}")
    if not records:
        raise SystemExit(f"Tidak ada record pada {CSV_PATH}; jalankan main.py terlebih dahulu.")
    return records


def main():
    records = load_records()
    prices = [Decimal(row["price_clean"]) for row in records]
    average = sum(prices, Decimal("0")) / len(prices)
    premium_count = sum(row["category"] == "Premium" for row in records)
    standard_count = len(records) - premium_count
    styles = build_styles()
    body = styles["BodyCopy"]
    small = styles["SmallCopy"]
    head = styles["TableHead"]
    story = [
        Spacer(1, 17 * mm),
        paragraph("UNIVERSITAS PELITA BANGSA · FAKULTAS TEKNIK", styles["CoverEyebrow"]),
        paragraph("LAPORAN UJIAN<br/>TENGAH SEMESTER", styles["CoverTitle"]),
        paragraph(
            "Automation Systems<br/><b>Online Book Catalog Organizer</b>",
            styles["CoverSubtitle"],
        ),
        Spacer(1, 6 * mm),
        make_table(
            [
                [paragraph("Identitas", head), paragraph("Keterangan", head)],
                [
                    paragraph("Nama", small),
                    paragraph("Muhammad Tafzil Rimzal", small),
                ],
                [paragraph("NIM", small), paragraph("312310529", small)],
                [paragraph("Kelompok", small), paragraph("Kelompok 01 · satu orang (telah dikonfirmasi kepada dosen pengampu)", small)],
                [paragraph("Mata kuliah", small), paragraph("Automation Systems · Teknik Informatika", small)],
                [paragraph("Semester", small), paragraph("Genap TA 2025/2026", small)],
            ],
            [45 * mm, 115 * mm],
        ),
        Spacer(1, 8 * mm),
        paragraph(
            "<b>Catatan administrasi:</b> lembar soal menetapkan tiga mahasiswa per kelompok. "
            "Laporan ini mencatat bahwa proyek dikerjakan sendiri. Jumlah anggota satu orang "
            "telah dikonfirmasi dan diperbolehkan oleh dosen pengampu.",
            styles["Callout"],
        ),
        paragraph("Ringkasan Proyek", styles["SectionHeading"]),
        paragraph(
            "Aplikasi CLI ini mengambil katalog latihan publik Books to Scrape, memvalidasi dan "
            "menormalkan harga, menyaring judul dengan kata kunci, menyimpan hasil ke CSV/TXT, "
            "menghasilkan katalog web lokal, dan membuat arsip ZIP. Pengguna mengatur sumber, "
            "filter, batas record, serta backup melalui argumen command line.",
            body,
        ),
        make_table(
            [
                [paragraph("RECORD", styles["CenterLabel"]), paragraph("RATA-RATA HARGA SUMBER", styles["CenterLabel"]), paragraph("PREMIUM", styles["CenterLabel"]), paragraph("STANDARD", styles["CenterLabel"])],
                [paragraph(str(len(records)), styles["CenterStat"]), paragraph(f"£{average:.2f}", styles["CenterStat"]), paragraph(str(premium_count), styles["CenterStat"]), paragraph(str(standard_count), styles["CenterStat"])],
            ],
            [40 * mm] * 4,
            header=False,
        ),
        Spacer(1, 4 * mm),
        paragraph(
            f"Dataset pada saat laporan dibuat berisi {len(records)} buku. Harga kategori Premium "
            "ditetapkan jika harga sumber lebih dari £30; selain itu Standard. Katalog web "
            "mengonversi harga dengan kurs acuan tetap £1 = Rp24.227 (6 November 2026), bukan kurs live.",
            small,
        ),
        PageBreak(),
        paragraph("1. Tujuan dan Alur Sistem", styles["SectionHeading"]),
        paragraph(
            "Masalah yang ditangani adalah pengumpulan dan penataan katalog yang secara manual "
            "memerlukan membuka halaman satu per satu. Program mengikuti tautan paginasi, mengambil "
            "judul, harga, URL detail, dan URL sampul; data kemudian dibersihkan, ditulis, "
            "ditampilkan, dan dibackup.",
            body,
        ),
        make_table(
            [
                [paragraph("Tahap", head), paragraph("Proses", head), paragraph("Hasil", head)],
                [paragraph("1 · Ambil", small), paragraph("requests mengambil halaman; BeautifulSoup membaca kartu buku dan tautan halaman berikutnya.", small), paragraph("Record buku dan URL terkait.", small)],
                [paragraph("2 · Validasi", small), paragraph("Validasi URL HTTP(S), harga, judul, dan batas --limit; cegah kunjungan ulang halaman.", small), paragraph("Data yang memenuhi format.", small)],
                [paragraph("3 · Olah", small), paragraph("Regex mengekstrak harga; regex keyword opsional menyaring judul; kategori harga dihitung.", small), paragraph("Data terstruktur sesuai filter.", small)],
                [paragraph("4 · Simpan", small), paragraph("pathlib membuat folder; CSV, TXT, laporan, dan halaman HTML ditulis ke output/data.", small), paragraph("Berkas hasil yang dapat dibuka kembali.", small)],
                [paragraph("5 · Backup", small), paragraph("zipfile mengarsipkan seluruh output dan raw_data.txt saat --backup digunakan.", small), paragraph("backup/backup_data.zip.", small)],
            ],
            [23 * mm, 89 * mm, 48 * mm],
        ),
        paragraph("2. Pemetaan Materi Wajib", styles["SectionHeading"]),
        make_table(
            [
                [paragraph("Materi", head), paragraph("Implementasi pada program", head), paragraph("Bukti", head)],
                [paragraph("Regular Expressions · Ch. 9", small), paragraph("PRICE_PATTERN mengambil angka harga; pola keyword dibangun dengan re.escape() dan re.IGNORECASE.", small), paragraph("main.py: PRICE_PATTERN, process_and_filter_data().", small)],
                [paragraph("Reading/Writing Files · Ch. 10", small), paragraph("pathlib.open(), write_text(), csv.DictWriter menulis file teks dan CSV UTF-8.", small), paragraph("data/raw_data.txt, output/*.csv, *.txt.", small)],
                [paragraph("Organizing Files · Ch. 11", small), paragraph("mkdir(parents=True, exist_ok=True), pathlib dan zipfile.", small), paragraph("data/, output/, backup/.", small)],
                [paragraph("CLI · Ch. 12", small), paragraph("argparse menerima --url, --keyword, --limit, --backup dengan validasi URL dan bilangan positif.", small), paragraph("python main.py --help.", small)],
                [paragraph("Web Scraping · Ch. 13", small), paragraph("requests dan BeautifulSoup mengambil kartu buku serta paginasi dari situs latihan.", small), paragraph("Books to Scrape · 30 record.", small)],
            ],
            [43 * mm, 79 * mm, 38 * mm],
        ),
        PageBreak(),
        paragraph("3. Data, Hasil, dan Cara Menjalankan", styles["SectionHeading"]),
        paragraph(
            "Sumber data adalah https://books.toscrape.com/, situs latihan web scraping. "
            "Pada pengambilan terakhir terkumpul 30 record; 20 diklasifikasikan Premium dan "
            "10 Standard. Rata-rata harga mentah adalah £37,21; nilai ini dihitung dari kolom "
            "harga GBP pada CSV.",
            body,
        ),
        paragraph("Contoh penggunaan:", styles["Heading3"]),
        make_table(
            [
                [paragraph("Perintah", head), paragraph("Tujuan", head)],
                [paragraph("<font name='Courier'>python main.py --limit 30 --backup</font>", small), paragraph("Ambil 30 record dan buat backup ZIP.", small)],
                [paragraph("<font name='Courier'>python main.py --keyword history --limit 30</font>", small), paragraph("Saring judul tanpa membedakan kapitalisasi.", small)],
                [paragraph("<font name='Courier'>python dokumentasi/generate_report.py</font>", small), paragraph("Buat ulang laporan PDF dari CSV terbaru.", small)],
            ],
            [88 * mm, 72 * mm],
        ),
        Spacer(1, 4 * mm),
        paragraph("Berkas keluaran", styles["Heading3"]),
        make_table(
            [
                [paragraph("Lokasi", head), paragraph("Isi", head)],
                [paragraph("data/raw_data.txt", small), paragraph("Record mentah yang diambil dari sumber.", small)],
                [paragraph("output/hasil_scraping.csv", small), paragraph("Judul, harga GBP, kategori harga, URL buku, dan URL gambar.", small)],
                [paragraph("output/laporan.txt", small), paragraph("Ringkasan proses dan rincian record terpilih.", small)],
                [paragraph("output/index.html", small), paragraph("Katalog responsif, pencarian, filter, pengurutan, dan harga IDR.", small)],
                [paragraph("backup/backup_data.zip", small), paragraph("Arsip output terkini dan raw_data.txt.", small)],
                [paragraph("dokumentasi/laporan_uts.pdf", small), paragraph("Laporan proyek ini.", small)],
            ],
            [60 * mm, 100 * mm],
        ),
        paragraph("4. Penanganan Kesalahan dan Etika", styles["SectionHeading"]),
        paragraph(
            "Program menolak URL yang tidak valid dan limit nonpositif melalui argparse. "
            "Kegagalan HTTP/koneksi, kegagalan file, data kosong, dan kegagalan proses yang "
            "dikenali ditampilkan ke stderr dengan status gagal. Record tanpa judul/harga yang "
            "valid dilewati dengan peringatan. Sumber merupakan situs latihan publik; scraper "
            "tidak melewati autentikasi atau pembatasan akses.",
            body,
        ),
        PageBreak(),
        paragraph("5. Batasan dan Pengembangan", styles["SectionHeading"]),
        make_table(
            [
                [paragraph("Batasan saat ini", head), paragraph("Pengembangan berikutnya", head)],
                [paragraph("Daftar buku yang di-scrape tidak menyediakan penulis pada kartu katalog; field penulis belum ada di dataset.", small), paragraph("Menggunakan sumber yang menyediakan metadata penulis atau mengambil detail buku jika tersedia dan diizinkan.", small)],
                [paragraph("Premium/Standard adalah klasifikasi berdasarkan ambang harga £30, bukan kategori genre dari situs.", small), paragraph("Ambil genre dari halaman detail buku dan pisahkan field kategori genre dari kategori harga.", small)],
                [paragraph("Kurs GBP/IDR untuk tampilan web disimpan sebagai angka tetap, sehingga tidak mengikuti kurs harian.", small), paragraph("Ambil kurs dari API secara terkontrol, simpan tanggal/sumber kurs, dan tangani kegagalan layanan kurs.", small)],
                [paragraph("Video demonstrasi belum disertakan; naskah dan urutan demo disiapkan terpisah.", small), paragraph("Rekam CLI, hasil katalog, pencarian/filter, dan proses backup sesuai naskah demo.", small)],
            ],
            [80 * mm, 80 * mm],
        ),
        paragraph("6. Kesimpulan", styles["SectionHeading"]),
        paragraph(
            "Program telah menunjukkan alur otomasi web scraping, regex, file I/O, organisasi "
            "berkas, backup, dan antarmuka CLI sesuai inti persyaratan teknis. Katalog web menjadi "
            "antarmuka tambahan untuk melihat, mencari, memfilter, dan mengurutkan hasil. Jumlah "
            "anggota satu orang telah dikonfirmasi dan diperbolehkan oleh dosen pengampu; video "
            "demo nyata tetap perlu direkam bila diminta.",
            body,
        ),
        paragraph("Berkas pengumpulan", styles["Heading3"]),
        paragraph(
            "Source code dan dependensi: main.py, requirements.txt. Dataset dan hasil: data/ dan "
            "output/. Backup: backup/backup_data.zip. Panduan instalasi/penggunaan: README.md. "
            "Laporan: dokumentasi/laporan_uts.pdf. Naskah demo: dokumentasi/naskah_demo.txt.",
            body,
        ),
        paragraph(
            "Kelompok satu orang telah dikonfirmasi dan diperbolehkan oleh dosen pengampu.",
            styles["Callout"],
        ),
    ]

    document = SimpleDocTemplate(
        str(REPORT_PATH),
        pagesize=A4,
        rightMargin=20 * mm,
        leftMargin=20 * mm,
        topMargin=19 * mm,
        bottomMargin=20 * mm,
        title="Laporan UTS Automation Systems - Online Book Catalog Organizer",
        author="Muhammad Tafzil Rimzal",
    )
    document.build(story, onFirstPage=page_chrome, onLaterPages=page_chrome)
    print(f"Laporan berhasil dibuat: {REPORT_PATH}")


if __name__ == "__main__":
    main()
